package com.emailapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emailapp.dao.EmailDAO;
import com.emailapp.domainobject.EmailDraftsDO;
import com.emailapp.domainobject.EmailInboxDO;
import com.emailapp.domainobject.EmailSentBoxDO;
import com.emailapp.domainobject.EmailTrashDO;

@Service
public class EmailService {

	@Autowired
	EmailDAO emailDAO;

	public boolean persist(EmailInboxDO emailinbox) {
		return emailDAO.persist(emailinbox);
	}

	public boolean persist(EmailSentBoxDO emailSent) {
		return emailDAO.persist(emailSent);
	}

	public boolean persist(EmailDraftsDO emailDraft) {
		return emailDAO.persist(emailDraft);
	}

	public boolean persist(EmailTrashDO emailTrash) {
		return emailDAO.persist(emailTrash);
	}

}
