package com.emailapp.util;

import java.io.*;
import javax.mail.*;

public class CommonWebEmailUtil {

	public static byte[] procesMultiPart(Multipart content) {
		byte[] attachments = null;
		try {

			for (int i = 0; i < content.getCount(); i++) {
				BodyPart bodyPart = content.getBodyPart(i);
				@SuppressWarnings("unused")
				Object o;

				o = bodyPart.getContent();
				if (null != bodyPart.getDisposition() && bodyPart.getDisposition().equalsIgnoreCase(Part.ATTACHMENT)) {
					InputStream inStream = bodyPart.getInputStream();
					// The outstream can be any output stream, I switch this to
					// one that writes to memory (byte[]).
					ByteArrayOutputStream outStream = new ByteArrayOutputStream();
					// ====================================
					byte[] tempBuffer = new byte[4096]; // 4 KB
					@SuppressWarnings("unused")
					int numRead;
					while ((numRead = inStream.read(tempBuffer)) != -1) {
						outStream.write(tempBuffer);
					}
					// ====================================
					// Handle object here
					byte[] attachment = outStream.toByteArray();
					attachments = attachment;
					System.out.println(attachment);

					inStream.close();
					outStream.close();
					return attachment;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		return attachments;
	}

}
