package com.emailapp.util;

import java.io.*;
import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.MimeMessage.RecipientType;

public class EmailUtil {

	public static void read(String host, String port, String userName, String password) {
		Session session = SingletonSession.getSession();
		Properties properties = session.getProperties();
		// server setting
		properties.put("mail.pop3.host", host);
		properties.put("mail.pop3.port", port);

		// SSL setting
		properties.setProperty("mail.pop3.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		properties.setProperty("mail.pop3.socketFactory.fallback", "false");
		properties.setProperty("mail.pop3.socketFactory.port", String.valueOf(port));

		// Session session = Session.getDefaultInstance(properties);

		try {
			// connects to the message store
			Store store = session.getStore("pop3");
			store.connect(userName, password);

			Folder[] folderList = store.getDefaultFolder().list();
			for (int i = 0; i < folderList.length; i++) {
				System.out.println(folderList[i].getFullName());
			}

			// opens the inbox folder
			Folder folderInbox = store.getFolder("INBOX");
			// Folder sentMail = store.getFolder( "[Gmail]" ).getFolder( "Sent
			// Mail" );
			folderInbox.open(Folder.READ_ONLY);

			// fetches new messages from server
			Message[] arrayMessages = folderInbox.getMessages();
			for (Message message2 : arrayMessages) {

				System.out.println(message2.getContent());

			}
			System.out.println(arrayMessages.length);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void smtpreader() throws MessagingException {
		String host = "mysite.smtp.com";
		Session session = SingletonSession.getSession();
		Properties props = session.getProperties();
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", "myport");
		props.put("mail.smtp.auth", "true");
		try {
			Store store = session.getStore();
			store.connect(host, "example123sample2695@gmail.com", "3131212123");
			Folder[] folderList = store.getDefaultFolder().list();
			for (int i = 0; i < folderList.length; i++) {
				System.out.println(folderList[i].getFullName());
			}
		} catch (NoSuchProviderException e) {
			e.printStackTrace();
		}
	}

	public void readMails() {

		Session session = MailSession.getSession();

		Properties properties = session.getProperties();
		properties.setProperty("mail.host", "imap.gmail.com");
		properties.setProperty("mail.port", "995");
		properties.setProperty("mail.transport.protocol", "imaps");
		try {
			Store store = session.getStore("imaps");
			store.connect();

			Folder[] folderList = store.getDefaultFolder().list();
			for (int i = 0; i < folderList.length; i++) {
				System.out.println(folderList[i].getFullName());
			}
			// Folder inbox = store.getFolder("[Gmail]");
			Folder inbox = store.getFolder("[Gmail]").getFolder("Trash");
			Folder[] sent = store.getFolder("[Gmail]").list();
			for (Folder folder : sent) {
				System.out.println(folder.getFullName());
			}
			// [Gmail]
			// [Gmail]/All Mail
			// [Gmail]/Drafts
			// [Gmail]/Important
			// [Gmail]/Sent Mail
			// [Gmail]/Spam
			// [Gmail]/Starred
			// [Gmail]/Trash
			inbox.open(Folder.READ_ONLY);
			// Message messages[] = inbox.search(new FlagTerm(new
			// Flags(Flag.SEEN), false));
			Message[] messages = inbox.getMessages();

			// Message messages[] = inbox.search(new FlagTerm(new
			// Flags(Flag.SEEN), false));
			System.out.println("Number of mails = " + messages.length);
			for (int i = 0; i < messages.length; i++) {
				Message message = messages[i];
				Address[] from = message.getFrom();
				System.out.println("-------------------------------");
				System.out.println("Date : " + message.getSentDate());
				System.out.println("From : " + from[0]);
				System.out.println("Subject: " + message.getSubject());
				System.out.println("to:" + message.getAllRecipients());
				System.out.println("sent date" + message.getSentDate());
				System.out.println("to :" + message.getRecipients(RecipientType.CC));
				// processMessageBody(message);
				System.out.println("--------------------------------");
			}
			inbox.close(true);
			store.close();
		} catch (NoSuchProviderException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	public void processMessageBody(Message message) {
		try {
			Object content = message.getContent();
			// check for string // then check for multipart
			if (content instanceof String) {
				System.out.println("=====String is printing====");
				System.out.println(content);
			} else if (content instanceof Multipart) {
				Multipart multiPart = (Multipart) content;
				procesMultiPart(multiPart);
			} else if (content instanceof InputStream) {
				@SuppressWarnings("resource")
				InputStream inStream = (InputStream) content;
				int ch;
				while ((ch = inStream.read()) != -1) {
					System.out.write(ch);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	public void procesMultiPart(Multipart content) {
		try {
			int multiPartCount = content.getCount();
			for (int i = 0; i < multiPartCount; i++) {
				BodyPart bodyPart = content.getBodyPart(i);
				Object o;
				o = bodyPart.getContent();
				if (o instanceof String) {
					System.out.println("===============im here=======");
					System.out.println(o);
				} else if (o instanceof Multipart) {
					procesMultiPart((Multipart) o);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

}
