package com.emailapp.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateSession {

	private HibernateSession() {

	}

	private static SessionFactory sf;

	public static SessionFactory getSf() {
		if (sf == null) {
			sf = new Configuration().configure().buildSessionFactory();
			return sf;
		}
		return sf;
	}
}
