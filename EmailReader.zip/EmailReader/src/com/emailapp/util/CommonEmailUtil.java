package com.emailapp.util;

import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.Scanner;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class CommonEmailUtil {

	public static Message[] readmailcontents(String folder) {
		Message[] message = null;
		Session session = MailSession.getSession();
		Properties properties = session.getProperties();
		properties.setProperty("mail.host", "imap.gmail.com");
		properties.setProperty("mail.port", "995");
		properties.setProperty("mail.transport.protocol", "imaps");
		try {
			Folder inbox = null;
			Store store = session.getStore("imaps");
			store.connect();
			if (folder.equals("INBOX")) {
				inbox = store.getFolder("INBOX");
			} else {
				inbox = store.getFolder("[Gmail]").getFolder(folder);
			}

			inbox.open(Folder.READ_ONLY);
			message = inbox.getMessages();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return message;
	}

	public static void sendMail() {
		final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";

		Session session = SingletonSession.getSession();
		// Overriding the JavaMail session properties to write
		Properties properties = session.getProperties();

		properties.setProperty("mail.smtp.host", "smtp.gmail.com");
		properties.setProperty("mail.smtp.socketFactory.class", SSL_FACTORY);
		properties.setProperty("mail.smtp.socketFactory.fallback", "false");
		properties.setProperty("mail.smtp.port", "465");
		properties.setProperty("mail.smtp.socketFactory.port", "465");
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.debug", "true");
		try {
			Message msg = new MimeMessage(session);
			msg.setSubject("this is sample");
			msg.setSentDate(new Date());
			msg.setFrom();
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("harish.salty@gmail.com", false));
			msg.setText("hello harish");
			Transport.send(msg);
			System.out.println("message sent..");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("static-access")
	public static int sendMail(String sss) throws MessagingException {
		final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";

		Session session = SingletonSession.getSession();

		// Overriding the JavaMail session properties to write
		Properties properties = session.getProperties();
		properties.setProperty("mail.host", "imap.gmail.com");
		properties.setProperty("mail.port", "995");
		properties.setProperty("mail.transport.protocol", "imaps");
		properties.setProperty("mail.smtp.host", "smtp.gmail.com");
		properties.setProperty("mail.smtp.socketFactory.class", SSL_FACTORY);
		properties.setProperty("mail.smtp.socketFactory.fallback", "false");
		properties.setProperty("mail.smtp.port", "465");
		properties.setProperty("mail.smtp.socketFactory.port", "465");
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.debug", "true");
		Folder inbox = null;
		Store store = session.getStore("imaps");
		store.connect();
		inbox = store.getFolder("INBOX");

		inbox.open(Folder.READ_ONLY);
		Message[] message = inbox.getMessages();
		System.out.println(message.length);
		int count = 0;
		for (Message msg : message) {
			String from = InternetAddress.toString(msg.getFrom());
			System.out.println(from);
			String replyTo = InternetAddress.toString(msg.getReplyTo());
			System.out.println(replyTo);
			String to = InternetAddress.toString(msg.getRecipients(Message.RecipientType.TO));
			System.out.println(to);
			String subject = msg.getSubject();
			System.out.println(subject);
			System.out.print("Do you want to reply [y/n] : ");
			@SuppressWarnings("resource")
			String ans = new Scanner(System.in).nextLine();
			if ("Y".equalsIgnoreCase(ans) || "y".equals(ans)) {
				Message replyMessage = new MimeMessage(session);
				replyMessage = (MimeMessage) msg.reply(false);
				replyMessage.setFrom(new InternetAddress(to));
				replyMessage.setText("Thanks harish");
				replyMessage.setReplyTo(msg.getReplyTo());

				Transport t = session.getTransport("smtp");

				try {
					t.connect();
					/*
					 * t.sendMessage(replyMessage,
					 * replyMessage.getAllRecipients());
					 */
					t.send(replyMessage);
					System.out.println("message sent");
					count++;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return count;
	}

	@SuppressWarnings("static-access")
	public static int forward() throws MessagingException, IOException {
		final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";

		Session session = SingletonSession.getSession();

		// Overriding the JavaMail session properties to write
		Properties properties = session.getProperties();
		properties.setProperty("mail.host", "imap.gmail.com");
		properties.setProperty("mail.port", "995");
		properties.setProperty("mail.transport.protocol", "imaps");
		properties.setProperty("mail.smtp.host", "smtp.gmail.com");
		properties.setProperty("mail.smtp.socketFactory.class", SSL_FACTORY);
		properties.setProperty("mail.smtp.socketFactory.fallback", "false");
		properties.setProperty("mail.smtp.port", "465");
		properties.setProperty("mail.smtp.socketFactory.port", "465");
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.debug", "true");
		Folder inbox = null;
		Store store = session.getStore("imaps");
		store.connect();
		inbox = store.getFolder("INBOX");

		inbox.open(Folder.READ_ONLY);
		Message[] message = inbox.getMessages();
		System.out.println(message.length);
		int count = 0;
		for (Message msg : message) {
			String from = InternetAddress.toString(msg.getFrom());
			System.out.println(from);
			String replyTo = InternetAddress.toString(msg.getReplyTo());
			System.out.println(replyTo);
			String too = InternetAddress.toString(msg.getRecipients(Message.RecipientType.TO));
			System.out.println(too);
			String subject = msg.getSubject();
			System.out.println(subject);
			System.out.print("Do you want to forward [y/n] : ");
			@SuppressWarnings("resource")
			String ans = new Scanner(System.in).nextLine();
			if ("Y".equalsIgnoreCase(ans) || "y".equals(ans)) {

				Message forward = new MimeMessage(session);
				String to = "harish.salty@gmail.com , harishgowda261995@gmail.com";
				InternetAddress[] parse = InternetAddress.parse(to.toString(), true);
				forward.setRecipients(Message.RecipientType.TO, parse);
				// forward.setRecipients(Message.RecipientType.TO,
				// InternetAddress.parse("harish.salty@gmail.com"));
				// forward.setRecipients(Message.RecipientType.TO,
				// msg.getRecipients(RecipientType.TO));
				forward.setSubject("Fwd: " + msg.getSubject());
				forward.setFrom(new InternetAddress(too));

				// Creating the message part
				MimeBodyPart messageBodyPart = new MimeBodyPart();
				// Creating a multipart message
				Multipart multipart = new MimeMultipart();
				// set content present in the message
				messageBodyPart.setContent(msg, "message/rfc822");
				// Add part to multi part
				multipart.addBodyPart(messageBodyPart);
				// Associate multi-part with message
				forward.setContent(multipart);
				// forward.setContent((Multipart) msg.getContent());
				forward.saveChanges();

				Transport t = session.getTransport("smtp");

				try {
					t.connect();
					/*
					 * t.sendMessage(replyMessage,
					 * replyMessage.getAllRecipients());
					 */
					t.send(forward);
					System.out.println("message sent");
					count++;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return count;
	}
}
