package com.emailapp.util;

public class CommonConstants {

	public static final String SUBJECT = "subject";

	public static final String RESULT = "reult";

	public static final String ERROR = "error";

	public static final String FROM = "from";

	public static final String CONTENT = "content";

	public static final String ID = "id";

	public static final String SUCCESS = "success";

	public static final String RESPONSE = "response";

	public static final String ERROR_MSG = "data can't be retrieved";

	public static final String SENT_MESG = "Your message sent successfully";

	public static final String DATA = "data";

	public static final Object FOLDER = "folder";

	public static final Object TO = "to";

}
