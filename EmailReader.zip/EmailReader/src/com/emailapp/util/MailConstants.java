package com.emailapp.util;

public class MailConstants {
	public static final String ALL_MAIL = "All Mail";

	public static final String DRAFTS = "Drafts";

	public static final String IMPORTANT = "Important";

	public static final String SENT_MAIL = "Sent Mail";

	public static final String SPAM = "Spam";

	public static final String STARRED = "Starred";

	public static final String TRASH = "Trash";

	public static final String INBOX = "INBOX";
}
