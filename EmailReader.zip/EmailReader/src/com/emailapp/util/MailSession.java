package com.emailapp.util;

import java.util.Properties;

import javax.mail.PasswordAuthentication;
import javax.mail.Session;

public class MailSession {

	private MailSession() {

	}

	private static Session session = Session.getInstance(new Properties(), new javax.mail.Authenticator() {
		protected PasswordAuthentication getPasswordAuthentication() {
			return new PasswordAuthentication("example123sample2695@gmail.com", "3131212123");
		}
	});

	public static Session getSession() {
		return session;

	}
}
