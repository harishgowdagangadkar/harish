package com.emailapp.util;

import javax.mail.Message;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CommonWebUtil {

	public static JSONObject readInputs(Message[] message) {
		JSONObject response = new JSONObject();
		JSONObject result = new JSONObject();
		try {
			result.put(CommonConstants.SUCCESS, true);
			result.put(CommonConstants.ERROR, "");
			JSONArray array = new JSONArray();
			for (Message message2 : message) {
				array.put(readAllData(message2));
			}
			result.put(CommonConstants.RESULT, array);
			response.put(CommonConstants.RESPONSE, result);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	private static JSONObject readAllData(Message message) throws JSONException, Exception {
		JSONObject result = new JSONObject();
		result.put(CommonConstants.SUBJECT, message.getSubject());
		result.put(CommonConstants.FROM, message.getFrom()[0].toString());
		result.put(CommonConstants.CONTENT, message.getContent().toString());
		return result;
	}

	public static JSONObject buildErrorResponse(String errorMsg) {
		JSONObject responseJSON = new JSONObject();
		JSONObject resultJSON = new JSONObject();
		try {
			resultJSON.put(CommonConstants.SUCCESS, false);
			resultJSON.put(CommonConstants.ERROR, errorMsg);
			// resultJSON.put(CommonConstants.ERROR_CODE, errorCode);
			resultJSON.put(CommonConstants.RESULT, CommonConstants.ERROR_MSG);
			responseJSON.put(CommonConstants.RESPONSE, resultJSON);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return responseJSON;
	}

	public static JSONObject buildSuccessResponse(String message) {
		JSONObject responseJSON = new JSONObject();
		JSONObject resultJSON = new JSONObject();
		try {
			resultJSON.put(CommonConstants.SUCCESS, true);
			resultJSON.put(CommonConstants.ERROR, "");
			resultJSON.put(CommonConstants.RESULT, message);
			responseJSON.put(CommonConstants.RESPONSE, resultJSON);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return responseJSON;
	}

	public static org.json.simple.JSONObject readInputParams(String string) {
		org.json.simple.parser.JSONParser parser = new org.json.simple.parser.JSONParser();
		org.json.simple.JSONObject json = null;
		try {
			json = (org.json.simple.JSONObject) parser.parse(string);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

}
