package com.emailapp.util;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;

public class SingletonSession {

	private static Session session=Session.getDefaultInstance(new Properties(), new Authenticator() {
		protected PasswordAuthentication getPasswordAuthentication() {
			return new PasswordAuthentication("example123sample2695@gmail.com", "3131212123");

		}
	});
	public static Session getSession(){
		return session;
		
	}
}
