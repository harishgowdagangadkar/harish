package com.emailapp.rs;

import java.io.IOException;

import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.InternetAddress;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.emailapp.domainobject.EmailDraftsDO;
import com.emailapp.domainobject.EmailInboxDO;
import com.emailapp.domainobject.EmailSentBoxDO;
import com.emailapp.domainobject.EmailTrashDO;
import com.emailapp.service.EmailService;
import com.emailapp.util.CommonConstants;
import com.emailapp.util.CommonEmailUtil;
import com.emailapp.util.CommonWebEmailUtil;
import com.emailapp.util.CommonWebUtil;
import com.emailapp.util.MailConstants;

@Controller
@RequestMapping(value = "/mail")
public class EmailRS {

	@Autowired
	EmailService emailService;

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public @ResponseBody String AddInbox(Model model) {
		try {
			Message[] message = CommonEmailUtil.readmailcontents(MailConstants.INBOX);
			int count = 0;
			for (Message message2 : message) {
				EmailInboxDO emailinbox = new EmailInboxDO();
				emailinbox.seteFrom(message2.getFrom()[0].toString());
				emailinbox.seteSubject(message2.getSubject());
				emailinbox.seteContent(message2.getContent().toString());
				String contentType = message2.getContentType();

				if (contentType.contains("multipart")) {
					// content may contain attachments
					Multipart multiPart = (Multipart) message2.getContent();
					byte[] attachment = CommonWebEmailUtil.procesMultiPart(multiPart);
					if (attachment != null) {
						emailinbox.setAttachments(attachment);
					}
				}
				if (!emailService.persist(emailinbox)) {
					count++;
				}
			}
			if (count == message.length) {
				return CommonWebUtil.buildErrorResponse("no new message is present").toString();
			}
		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return CommonWebUtil.buildSuccessResponse("your data is added succesfully").toString();
	}

	@RequestMapping(value = "/addsentmail", method = RequestMethod.GET)
	public @ResponseBody String AddSentBox(Model model) {
		try {
			Message[] message = CommonEmailUtil.readmailcontents(MailConstants.SENT_MAIL);
			int count = 0;
			for (Message message2 : message) {
				EmailSentBoxDO emailSent = new EmailSentBoxDO();
				emailSent.setEsubject(message2.getSubject());
				emailSent.setEto(InternetAddress.toString(message2.getRecipients(Message.RecipientType.TO)));
				emailSent.setContent(message2.getContent().toString());
				System.out.println("replyto= " + InternetAddress.toString(message2.getReplyTo()));
				System.out.println(message2.getAllRecipients());
				if (!emailService.persist(emailSent)) {
					count++;
				}
			}
			if (count == message.length) {
				return CommonWebUtil.buildErrorResponse("no new message is present").toString();
			}
		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return CommonWebUtil.buildSuccessResponse("your data is added succesfully").toString();
	}

	@RequestMapping(value = "/adddraftmail", method = RequestMethod.GET)
	public @ResponseBody String AddDraft(Model model) {
		try {
			Message[] message = CommonEmailUtil.readmailcontents(MailConstants.DRAFTS);
			int count = 0;
			for (Message message2 : message) {
				EmailDraftsDO emailDraft = new EmailDraftsDO();
				emailDraft.setEsubject(message2.getSubject());
				emailDraft.setEto(message2.getRecipients(RecipientType.TO).toString());
				emailDraft.setContent(message2.getContent().toString());

				if (!emailService.persist(emailDraft)) {
					count++;
				}
			}
			if (count == message.length) {
				return CommonWebUtil.buildErrorResponse("no new message is present").toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "your action is failed try later";
		}
		return CommonWebUtil.buildSuccessResponse("your data is added succesfully").toString();
	}

	@RequestMapping(value = "/addtrashmail", method = RequestMethod.GET)
	public @ResponseBody String AddTrash(Model model) {
		try {
			Message[] message = CommonEmailUtil.readmailcontents(MailConstants.TRASH);
			int count = 0;
			for (Message message2 : message) {
				EmailTrashDO emailTrash = new EmailTrashDO();
				emailTrash.setEsubject(message2.getSubject());
				emailTrash.setEto(message2.getRecipients(RecipientType.TO).toString());
				emailTrash.setContent(message2.getContent().toString());
				if (!emailService.persist(emailTrash)) {
					count++;
				}
			}
			if (count == message.length) {
				return CommonWebUtil.buildErrorResponse("no new message is present").toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "your action is failed try later";
		}
		return CommonWebUtil.buildSuccessResponse("your data is added succesfully").toString();

	}

	@RequestMapping(value = "/read", method = RequestMethod.GET)
	public @ResponseBody String readfolder(HttpServletRequest request) {
		Message[] message = null;
		org.json.simple.JSONObject json = CommonWebUtil
				.readInputParams(request.getParameter(CommonConstants.DATA).toString());
		if (json.get(CommonConstants.FOLDER).toString().contains("inbox")) {
			message = CommonEmailUtil.readmailcontents(MailConstants.INBOX);
		} else if (json.get(CommonConstants.FOLDER).toString().contains("all mail")) {
			message = CommonEmailUtil.readmailcontents(MailConstants.ALL_MAIL);
		} else if (json.get(CommonConstants.FOLDER).toString().contains("drafts")) {
			message = CommonEmailUtil.readmailcontents(MailConstants.DRAFTS);
		} else if (json.get(CommonConstants.FOLDER).toString().contains("trash")) {
			message = CommonEmailUtil.readmailcontents(MailConstants.TRASH);
		} else if (json.get(CommonConstants.FOLDER).toString().contains("sent mail")) {
			message = CommonEmailUtil.readmailcontents(MailConstants.SENT_MAIL);
		} else {
			return CommonWebUtil.buildErrorResponse("folder not found").toString();
		}
		try {
			JSONObject results = CommonWebUtil.readInputs(message);
			return results.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return CommonWebUtil.buildErrorResponse("your action failed").toString();
		}
	}

	@RequestMapping(value = "/send", method = RequestMethod.GET)
	public @ResponseBody String sendMail() {
		try {
			CommonEmailUtil.sendMail();
			return CommonWebUtil.buildSuccessResponse("message sent succesfully").toString();
		} catch (Exception e) {
			e.printStackTrace();
			return CommonWebUtil.buildErrorResponse("your message is not sent").toString();

		}
	}

	@RequestMapping(value = "/reply", method = RequestMethod.GET)
	public @ResponseBody String replyMsg(HttpServletRequest request) {
		try {
			// if(json.get(CommonConstants.TO) != null){
			if (CommonEmailUtil.sendMail("") != 0) {
				return CommonWebUtil.buildSuccessResponse("message sent succesfully").toString();
			}
			// }else{
			// return CommonWebUtil.buildErrorResponse("provide valid
			// credentials").toString();
			// }
		} catch (Exception e) {
			e.printStackTrace();
			return CommonWebUtil.buildErrorResponse("your message is not sent").toString();

		}
		return CommonWebUtil.buildErrorResponse("your message is not sent").toString();
	}

	@RequestMapping(value = "/forward", method = RequestMethod.GET)
	public @ResponseBody String forwardMail() {
		try {
			CommonEmailUtil.forward();
			return CommonWebUtil.buildSuccessResponse("message sent succesfully").toString();
		} catch (Exception e) {
			e.printStackTrace();
			return CommonWebUtil.buildErrorResponse("your message is not sent").toString();

		}
	}
}
