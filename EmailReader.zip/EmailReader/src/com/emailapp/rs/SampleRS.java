package com.emailapp.rs;

import javax.mail.MessagingException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.emailapp.util.EmailUtil;

@Controller
@RequestMapping(value = "/email")
public class SampleRS {

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public @ResponseBody String sample(Model model) {
		return "success";

	}

	@RequestMapping(value = "/read", method = RequestMethod.GET)
	public @ResponseBody String read() {
		String host = "pop.gmail.com";
		String port = "995";
		String userName = "example123sample2695@gmail.com";
		// String userName = "harish.salty@gmail.com";
		String password = "3131212123";
		EmailUtil.read(host, port, userName, password);
		return "read";
	}

	@RequestMapping(value = "/re", method = RequestMethod.GET)
	public @ResponseBody String read(Model model) throws MessagingException {
		new EmailUtil().readMails();
		return "success";

	}
}
