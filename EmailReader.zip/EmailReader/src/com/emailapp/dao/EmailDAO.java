package com.emailapp.dao;

import java.util.List;

import org.hibernate.Session;

import com.emailapp.domainobject.EmailDraftsDO;
import com.emailapp.domainobject.EmailInboxDO;
import com.emailapp.domainobject.EmailSentBoxDO;
import com.emailapp.domainobject.EmailTrashDO;
import com.emailapp.util.CommonConstants;
import com.emailapp.util.HibernateSession;

public class EmailDAO {

	public boolean persist(EmailInboxDO emailinbox) {

		boolean status = true;
		Session session = HibernateSession.getSf().openSession();
		try {
			@SuppressWarnings("unchecked")
			List<EmailInboxDO> list = session.getNamedQuery(EmailInboxDO.FIND_BY_SUBJECT)
					.setParameter(CommonConstants.SUBJECT, emailinbox.geteSubject()).list();
			if (list != null && list.size() > 0) {
				status = false;
			} else {
				session.save(emailinbox);
				session.beginTransaction().commit();
			}
		} catch (Exception e) {
			status = false;
			e.printStackTrace();
		}
		return status;
	}

	public boolean persist(EmailSentBoxDO emailSent) {
		boolean status = true;
		Session session = HibernateSession.getSf().openSession();
		try {
			@SuppressWarnings("unchecked")
			List<EmailSentBoxDO> list = session.getNamedQuery(EmailSentBoxDO.FIND_BY_SUBJECT)
					.setParameter(CommonConstants.SUBJECT, emailSent.getEsubject()).list();
			if (list != null && list.size() > 0) {
				status = false;
			} else {
				session.save(emailSent);
				session.beginTransaction().commit();
			}
		} catch (Exception e) {
			status = false;
			e.printStackTrace();
		}
		return status;
	}

	public boolean persist(EmailDraftsDO emailDraft) {
		boolean status = true;
		Session session = HibernateSession.getSf().openSession();
		try {
			@SuppressWarnings("unchecked")
			List<EmailDraftsDO> list = session.getNamedQuery(EmailDraftsDO.FIND_BY_SUBJECT)
					.setParameter(CommonConstants.SUBJECT, emailDraft.getEsubject()).list();
			if (list != null && list.size() > 0) {
				status = false;
			} else {
				session.save(emailDraft);
				session.beginTransaction().commit();
			}
		} catch (Exception e) {
			status = false;
			e.printStackTrace();
		}
		return status;
	}

	public boolean persist(EmailTrashDO emailTrash) {
		boolean status = true;
		Session session = HibernateSession.getSf().openSession();
		try {
			@SuppressWarnings("unchecked")
			List<EmailTrashDO> list = session.getNamedQuery(EmailTrashDO.FIND_BY_SUBJECT)
					.setParameter(CommonConstants.SUBJECT, emailTrash.getEsubject()).list();
			if (list != null && list.size() > 0) {
				status = false;
			} else {
				session.save(emailTrash);
				session.beginTransaction().commit();
			}
		} catch (Exception e) {
			status = false;
			e.printStackTrace();
		}
		return status;
	}

}
