package com.emailapp.domainobject;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="emailInbox")
@TableGenerator(name="emailInbox",initialValue=1,allocationSize=1)
@NamedQueries({
	@NamedQuery(name="emailInbox.readbySubject",query="SELECT c FROM EmailInboxDO c where eSubject=:subject"),
})
public class EmailInboxDO implements Serializable {
	private static final long serialVersionUID = 1L;

	public static final String FIND_BY_SUBJECT = "emailInbox.readbySubject";

	@Id
	@GenericGenerator(name="gener",strategy="increment")
	@GeneratedValue(generator="gener")
	private int id;
	
	private String eSubject;
	
	
	private String eContent;
	
	private String eFrom;
	
	@Lob
	@Column(columnDefinition = "mediumblob")
	private byte[] attachments;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String geteSubject() {
		return eSubject;
	}

	public void seteSubject(String eSubject) {
		this.eSubject = eSubject;
	}


	public String geteContent() {
		return eContent;
	}

	public void seteContent(String eContent) {
		this.eContent = eContent;
	}

	public String geteFrom() {
		return eFrom;
	}

	public void seteFrom(String eFrom) {
		this.eFrom = eFrom;
	}

	public byte[] getAttachments() {
		return attachments;
	}

	public void setAttachments(byte[] attachments) {
		this.attachments = attachments;
	}
	
}
