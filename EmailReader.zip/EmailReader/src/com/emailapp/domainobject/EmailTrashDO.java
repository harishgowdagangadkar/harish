package com.emailapp.domainobject;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "trashmail")
@TableGenerator(name = "trashmail", initialValue = 1, allocationSize = 1)
@NamedQueries({
		@NamedQuery(name = "trashmail.findbysubject", query = "SELECT r FROM EmailTrashDO r where esubject=:subject") })
public class EmailTrashDO implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String FIND_BY_SUBJECT = "trashmail.findbysubject";

	@Id
	@GenericGenerator(name = "genn", strategy = "increment")
	@GeneratedValue(generator = "genn")
	private int id;

	private String eto;

	private String esubject;

	private String content;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getEto() {
		return eto;
	}

	public void setEto(String eto) {
		this.eto = eto;
	}

	public String getEsubject() {
		return esubject;
	}

	public void setEsubject(String esubject) {
		this.esubject = esubject;
	}
}
