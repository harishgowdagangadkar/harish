package com.countrystate.domainobject;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "state_table")
@TableGenerator(name = "state_table", initialValue = 100101, allocationSize = 1)
@NamedQueries({ @NamedQuery(name = "state_table.findAll", query = "SELECT r FROM StateDO r"),
		@NamedQuery(name = "state_table.findByStateId", query = "SELECT r FROM StateDO r where r.stateId =:stateID"),
		@NamedQuery(name = "state_table.findByCountrId", query = "SELECT r FROM StateDO r where r.country.countryId =:countryId"),
		@NamedQuery(name = "state_table.findByCountryName", query = "SELECT r FROM StateDO r where r.country.countryName=:countryname"),
		@NamedQuery(name = "state_table.findByStateName", query = "SELECT r FROM StateDO r where r.stateName =:stateName"), })
public class StateDO implements Serializable{

	private static final long serialVersionUID = 1L;

	public static final String FIND_ALL = "state_table.findAll";

	public static final String FIND_BY_STATE_ID = "state_table.findByStateId";

	public static final String FIND_BY_COUNTRY_ID = "state_table.findByCountrId";

	public static final String FIND_BY_COUNTRY_NAME = "state_table.findByCountryName";

	public static final String FIND_COUNTRY_NAME = "state_table.findByStateName";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, unique = true)
	private Long stateId;

	private String stateName;

	@ManyToOne
	@JoinColumn(name = "countryId")
	private CountryDO country;

	public Long getStateId() {
		return stateId;
	}

	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public CountryDO getCountry() {
		return country;
	}

	public void setCountry(CountryDO country) {
		this.country = country;
	}

}
