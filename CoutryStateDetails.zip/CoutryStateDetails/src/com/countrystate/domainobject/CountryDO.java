package com.countrystate.domainobject;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "country_table")
@TableGenerator(name = "country_table", initialValue = 100101, allocationSize = 1)
@NamedQueries({
		@NamedQuery(name = "country_table.findById", query = "SELECT r FROM CountryDO r where r.countryId =:id"),
		@NamedQuery(name = "country_table.findByAll", query = "SELECT r FROM CountryDO r"),
		@NamedQuery(name = "country_table.findByCountryName", query = "SELECT r FROM CountryDO r where r.countryName =:countryname "), })
public class CountryDO implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String FIND_BY_ID = "country_table.findById";

	public static final String FIND_COUNTRY_NAME = "country_table.findByCountryName";

	public static final String FIND_BY_ALL = "country_table.findByAll";

	@Id
	@GenericGenerator(name = "gen", strategy = "increment")
	@GeneratedValue(generator = "gen")
	@Column(nullable = false, unique = true)
	private Long countryId;

	private String countryName;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdon;

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public Date getCreatedon() {
		return createdon;
	}

	public void setCreatedon(Date createdon) {
		this.createdon = createdon;
	}

}