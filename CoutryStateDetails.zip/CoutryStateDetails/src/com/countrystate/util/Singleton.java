package com.countrystate.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Singleton {

	

	private static SessionFactory sf;

	private Singleton() {
		// TODO Auto-generated constructor stub
	}

	public static SessionFactory getSf() {
		if(sf==null) {
			sf=new Configuration().configure().buildSessionFactory();
			return sf;
		}
		return sf;
	}
}
