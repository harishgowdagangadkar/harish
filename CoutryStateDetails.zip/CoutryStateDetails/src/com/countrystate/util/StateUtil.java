package com.countrystate.util;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.countrystate.domainobject.CountryDO;
import com.countrystate.domainobject.StateDO;

public class StateUtil {

	public JSONObject getStateList(List<StateDO> stateList) {

		JSONObject responseJSON = new JSONObject();
		JSONObject resultJSON = new JSONObject();
		try {
			resultJSON.put(CommonConstatns.SUCCESS, CommonConstatns.TRUE);
			resultJSON.put(CommonConstatns.ERROR, "");
			JSONArray resultJSONArray = new JSONArray();
			for (StateDO stateDO : stateList) {
				resultJSONArray.put(getDetailObject(stateDO));
			}
			resultJSON.put(CommonConstatns.RESULT, resultJSONArray);
			responseJSON.put(CommonConstatns.RESPONSE, resultJSON);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return responseJSON;

	}

	private JSONObject getDetailObject(StateDO stateDO) throws JSONException {
		JSONObject results = new JSONObject();
		CountryDO countryDO = (CountryDO) stateDO.getCountry();
		results.put(CommonConstatns.ID, stateDO.getStateId());
		results.put(CommonConstatns.NAME, stateDO.getStateName());
		results.put(CommonConstatns.COUNTRYID, countryDO.getCountryId());
		results.put(CommonConstatns.COUNTRY_NAME, countryDO.getCountryName());
		results.put(CommonConstatns.CREATED_ON, countryDO.getCreatedon());
		return results;
	}

}
