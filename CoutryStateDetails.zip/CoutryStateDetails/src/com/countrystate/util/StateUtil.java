package com.countrystate.util;

import java.util.Collection;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.countrystate.domainobject.CountryDO;
import com.countrystate.domainobject.StateDO;

public class StateUtil {

	public JSONObject getdetaliList(List<StateDO> detailsDO) {
	
		JSONObject resultJSON = new JSONObject();
		JSONObject responseJSON = new JSONObject();
		try {
			
			JSONArray resultJSONArray = new JSONArray();
			for (StateDO stateDO : detailsDO) {
				resultJSONArray.put(getDetailObject(stateDO));
				
				resultJSON.put(CommonConstats.SUCCESS, "data present");
				resultJSON.put(CommonConstats.ERROR, "");
			}
			resultJSON.put(CommonConstats.RESULT, resultJSONArray);
			responseJSON.put(CommonConstats.DISPLAY_ALL_RESULT, resultJSON);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return responseJSON;
	}

	private JSONObject getDetailObject(StateDO stateDO) throws JSONException {
		
		JSONObject reluts=new JSONObject();
		CountryDO countryDO=stateDO.getCountry();
		reluts.put(CommonConstats.STATE_ID,stateDO.getStateId());
		reluts.put(CommonConstats.STATE_NAME,stateDO.getStateName());
		reluts.put(CommonConstats.ID,countryDO.getCountryId());
		reluts.put(CommonConstats.ID,countryDO.getCountryId());
		reluts.put(CommonConstats.COUNTRY_NAME,countryDO.getCountryName());
		reluts.put(CommonConstats.CREATED_ON, countryDO.getCreatedon());
		return reluts;
	}
	
	
	

}
