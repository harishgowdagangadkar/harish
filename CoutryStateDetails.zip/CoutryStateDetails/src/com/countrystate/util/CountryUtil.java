package com.countrystate.util;

import java.text.ParseException;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.countrystate.domainobject.CountryDO;
import com.countrystate.service.CountryService;

public class CountryUtil {
	CountryService countryService = new CountryService();

	public JSONObject getdetaliList(List<CountryDO> detailsDO) throws ParseException {

		JSONObject responseJSON = new JSONObject();
		JSONObject resultJSON = new JSONObject();
		try {
			resultJSON.put(CommonConstatns.SUCCESS, CommonConstatns.TRUE);
			resultJSON.put(CommonConstatns.ERROR, "");
			JSONArray resultJSONArray = new JSONArray();
			for (CountryDO countryDO : detailsDO) {
				resultJSONArray.put(getDetailObject(countryDO));
			}
			resultJSON.put(CommonConstatns.RESULT, resultJSONArray);
			responseJSON.put(CommonConstatns.RESPONSE, resultJSON);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return responseJSON;

	}

	private JSONObject getDetailObject(CountryDO countryDO) throws JSONException, ParseException {
		JSONObject reluts = new JSONObject();
		reluts.put(CommonConstatns.ID, countryDO.getCountryId());
		reluts.put(CommonConstatns.NAME, countryDO.getCountryName());
		CommonUtil.formatDate(countryDO.getCreatedon());
		reluts.put(CommonConstatns.CREATED_ON, countryDO.getCreatedon());
		return reluts;
	}

	

	public JSONObject deleteRequested(CountryDO countryDO) throws JSONException {

		JSONObject resultJSON = new JSONObject();
		JSONObject responsebject = new JSONObject();

		if (countryService.delete(countryDO)) {
			resultJSON.put(CommonConstatns.SUCCESS, "data deleted");
			resultJSON.put(CommonConstatns.ERROR, "");
		} else {
			resultJSON.put(CommonConstatns.ERROR, "data not deleted");
			resultJSON.put(CommonConstatns.ERROR, "");
		}

		return responsebject.put(CommonConstatns.RESULT, resultJSON);

	}

}
