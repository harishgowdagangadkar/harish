package com.countrystate.util;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.countrystate.domainobject.CountryDO;
import com.countrystate.service.CountryService;

public class CountryUtil {
	CountryService countryService=new CountryService();
	public JSONObject getdetaliList(List<CountryDO> detailsDO) {
		
		JSONObject resultJSON = new JSONObject();
		JSONObject responseJSON = new JSONObject();
		try {
			
			JSONArray resultJSONArray = new JSONArray();
			for (CountryDO countryDO : detailsDO) {
				resultJSONArray.put(getDetailObject(countryDO));
				resultJSON.put(CommonConstats.SUCCESS, "data present");
				resultJSON.put(CommonConstats.ERROR, "");
			}
			resultJSON.put(CommonConstats.RESULT, resultJSONArray);
			
			responseJSON.put(CommonConstats.DISPLAY_ALL_RESULT, resultJSON);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return responseJSON;
	}

	private JSONObject getDetailObject(CountryDO countryDO) throws JSONException {
		JSONObject reluts=new JSONObject();
		reluts.put(CommonConstats.ID, countryDO.getCountryId());
		reluts.put(CommonConstats.NAME,countryDO.getCountryName());
		reluts.put(CommonConstats.CREATED_ON, countryDO.getCreatedon());
		return reluts;
	}

	public JSONObject deleteRequested(CountryDO countryDO) throws JSONException {
		
		JSONObject resultJSON = new JSONObject();
		JSONObject responsebject=new JSONObject();

				if(countryService.delete(countryDO)){
					resultJSON.put(CommonConstats.SUCCESS, "data deleted");
					resultJSON.put(CommonConstats.ERROR, "");
				}else{
					resultJSON.put(CommonConstats.ERROR, "data not deleted");
					resultJSON.put(CommonConstats.ERROR, "");
				}
	
		
		return responsebject.put(CommonConstats.RESULT, resultJSON);
		
	}

	
}
