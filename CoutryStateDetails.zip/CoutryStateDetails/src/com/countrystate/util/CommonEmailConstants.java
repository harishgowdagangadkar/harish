package com.countrystate.util;

public class CommonEmailConstants {
	
	public static final String SUBJECT = "Subject";

	public static final String FROM = "From";

	public static final Object USERNAME = "username";

	public static final Object PASSWORD = "password";

	public static final Object TO = "to";
}
