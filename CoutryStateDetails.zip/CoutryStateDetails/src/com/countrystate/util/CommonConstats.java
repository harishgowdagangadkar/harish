package com.countrystate.util;


public class CommonConstats {

	public static final String NAME = "name";
	public static final String COUNTRY_ID = "1";
	public static final String ID = "id";
	public static final String SUCCESS_MSG = "inserted succesfully";
	public static final String ERROR_MSG = "insertion failed";
	public static final String CREATED_ON = "created on";
	public static final String RESULT = "result";
	public static final String SUCCESS = "success";
	public static final String ERROR = "error";
	public static final String STATE_ID = "stateID";
	public static final String STATE_NAME = "State Name";
	public static final String COUNTRY_NAME = "Country Name";
	public static final String DISPLAY_ALL_RESULT = "displaying all details";
	public static final String DATA = "data";
	
	
	
}
