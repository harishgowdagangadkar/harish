package com.countrystate.util;


public class CommonConstatns {

	public static final String NAME = "name";

	public static final String COUNTRY_ID = "1";

	public static final String ID = "id";

	public static final String SUCCESS_MSG = "inserted succesfully";

	public static final String ERROR_MSG = "action failed";

	public static final String CREATED_ON = "created on";

	public static final String RESULT = "result";

	public static final String SUCCESS = "success";

	public static final String ERROR = "error";

	public static final String STATE_ID = "stateID";

	public static final String STATE_NAME = "stateName";

	public static final String COUNTRY_NAME = "countryname";

	public static final String DISPLAY_ALL_RESULT = "displaying all details";

	public static final String DATA = "data";

	public static final String RESPONSE = "reaponse";

	public static final String COUNTRYID = "countryId";

	public static final boolean TRUE = true;

	public static final String UPDATED_MESG = "your action is success";

	public static final boolean FALSE = false;

	public static final String EMAILSENT_MSG = "your mesg sent";



}
