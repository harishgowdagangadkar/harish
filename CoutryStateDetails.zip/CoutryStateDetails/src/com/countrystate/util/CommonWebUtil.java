package com.countrystate.util;

import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class CommonWebUtil {

	public static org.json.simple.JSONObject getInputParams(String string) {
	
		JSONParser parser = new JSONParser(); 
		org.json.simple.JSONObject inputJSON=new org.json.simple.JSONObject();
		try {
			
			inputJSON = (org.json.simple.JSONObject) parser.parse(string);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return inputJSON;

		}
}