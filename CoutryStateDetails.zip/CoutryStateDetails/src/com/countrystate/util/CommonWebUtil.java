package com.countrystate.util;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class CommonWebUtil {

	public static org.json.simple.JSONObject getInputParams(String string) {
		JSONParser parser = new JSONParser();
		org.json.simple.JSONObject inputJSON = new org.json.simple.JSONObject();
		try {

			inputJSON = (org.json.simple.JSONObject) parser.parse(string);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return inputJSON;
	}

	public static JSONObject buildSuccessResponse() {
		JSONObject responseJSON = new JSONObject();
		JSONObject resultJSON = new JSONObject();
		try {

			resultJSON.put(CommonConstatns.SUCCESS, CommonConstatns.TRUE);
			resultJSON.put(CommonConstatns.ERROR, "");
			resultJSON.put(CommonConstatns.RESULT, CommonConstatns.UPDATED_MESG);

			responseJSON.put(CommonConstatns.RESPONSE, resultJSON);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return responseJSON;
	}

	public static JSONObject buildErrorResponse(String errorMsg) {
		JSONObject responseJSON = new JSONObject();
		JSONObject resultJSON = new JSONObject();
		try {
			resultJSON.put(CommonConstatns.SUCCESS, CommonConstatns.FALSE);
			resultJSON.put(CommonConstatns.ERROR, errorMsg);
			// resultJSON.put(CommonConstants.ERROR_CODE, errorCode);
			resultJSON.put(CommonConstatns.RESULT, CommonConstatns.ERROR_MSG);
			responseJSON.put(CommonConstatns.RESPONSE, resultJSON);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return responseJSON;
	}

	public static JSONObject buildEmailSuccessResponse() {
		JSONObject responseJSON = new JSONObject();
		JSONObject resultJSON = new JSONObject();
		try {

			resultJSON.put(CommonConstatns.SUCCESS, CommonConstatns.TRUE);
			resultJSON.put(CommonConstatns.ERROR, "");
			resultJSON.put(CommonConstatns.RESULT, CommonConstatns.EMAILSENT_MSG);

			responseJSON.put(CommonConstatns.RESPONSE, resultJSON);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return responseJSON;
	}
}