package com.countrystate.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.mail.Message;
import javax.mail.MessagingException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class CommonUtil {

	public static void formatDate(Date createdon) {
		SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
		String da = date.format(createdon);
		System.out.println(da);

	}

	public static JSONObject getEmailInbox(Message[] message) throws MessagingException {

		JSONObject responseJSON = new JSONObject();
		JSONObject resultJSON = new JSONObject();
		try {
			resultJSON.put(CommonConstatns.SUCCESS, CommonConstatns.TRUE);
			resultJSON.put(CommonConstatns.ERROR, "");
			JSONArray resultJSONArray = new JSONArray();
			for (Message message2 : message) {
				resultJSONArray.put(getDetailObject(message2));
			}
			resultJSON.put(CommonConstatns.RESULT, resultJSONArray);
			responseJSON.put(CommonConstatns.RESPONSE, resultJSON);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return responseJSON;
	}

	private static JSONObject getDetailObject(Message message) throws JSONException, MessagingException {
		JSONObject json=new JSONObject();
		json.put(CommonEmailConstants.SUBJECT, message.getSubject());
		json.put(CommonEmailConstants.FROM,message.getFrom()[0]);
		return json;
	}

}
