package com.countrystate.DAO;

import java.util.List;

import org.hibernate.Session;

import com.countrystate.domainobject.CountryDO;
import com.countrystate.domainobject.StateDO;
import com.countrystate.util.CommonConstatns;
import com.countrystate.util.Singleton;

public class StateDAO {

	Session session = Singleton.getSf().openSession();

	public boolean persist(StateDO stateDO) {

		boolean status = true;

		try {

			session.save(stateDO);
			session.beginTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		}
		return status;
	}

	@SuppressWarnings("unchecked")
	public List<StateDO> retriveAll() {
		return session.getNamedQuery(StateDO.FIND_ALL).list();
	}

	@SuppressWarnings("unchecked")
	public List<StateDO> retrievebyID(long id) {
		return session.getNamedQuery(StateDO.FIND_BY_STATE_ID).setParameter(CommonConstatns.STATE_ID, id).list();
	}

	@SuppressWarnings("finally")
	public boolean update(StateDO stateDO) {
		boolean status = true;

		try {
			@SuppressWarnings("unchecked")
			List<StateDO> list = session.getNamedQuery(StateDO.FIND_COUNTRY_NAME)
					.setParameter(CommonConstatns.STATE_NAME, stateDO.getStateName()).list();
			if (list != null && list.size() > 0) {
				status = false;
			} else {
				session.update(stateDO);
				session.beginTransaction().commit();
			}
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			return status;
		}
	}

	@SuppressWarnings("finally")
	public boolean delete(StateDO stateDO) {
		boolean status = true;

		try {
			session.delete(stateDO);
			session.beginTransaction().commit();

		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		} finally {
			return status;
		}
	}

	@SuppressWarnings("unchecked")
	public List<StateDO> find(String string) {
		List<StateDO> list = null;
		try {

			list = session.getNamedQuery(StateDO.FIND_BY_COUNTRY_NAME).setParameter(CommonConstatns.COUNTRY_NAME, string)
					.list();
			if (list != null && list.size() > 0) {
				for (StateDO stateDO : list) {
					System.out.println(stateDO.getStateName());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public void findall(String string) {
		CountryDO countrDO = (CountryDO) session.getNamedQuery(CountryDO.FIND_COUNTRY_NAME)
				.setParameter(CommonConstatns.COUNTRY_NAME, string).uniqueResult();
		@SuppressWarnings("unchecked")
		List<StateDO> list = session.getNamedQuery(StateDO.FIND_BY_COUNTRY_ID)
				.setParameter(CommonConstatns.COUNTRYID, countrDO.getCountryId()).list();
		if (list != null && list.size() > 0) {
			for (StateDO stateDO : list) {
				System.out.println(stateDO.getStateName());
			}
		}
	}

	public StateDO retrievebyUniqueID(long id) {
		return (StateDO) session.getNamedQuery(StateDO.FIND_BY_STATE_ID).setParameter(CommonConstatns.STATE_ID, id)
				.uniqueResult();
	}

}