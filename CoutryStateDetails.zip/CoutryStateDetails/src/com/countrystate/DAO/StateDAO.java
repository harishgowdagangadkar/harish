package com.countrystate.DAO;

import java.util.List;

import org.hibernate.Session;

import com.countrystate.domainobject.CountryDO;
import com.countrystate.domainobject.StateDO;
import com.countrystate.util.CommonConstats;
import com.countrystate.util.Singleton;

public class StateDAO {

	Session session = Singleton.getSf().openSession();
	public boolean persist(StateDO stateDO) {
		
	boolean status=true;
	
	try {
		
		session.save(stateDO);
		session.beginTransaction().commit();
	} catch (Exception e) {
		e.printStackTrace();
		status=false;
	}
	return status;
	}

	@SuppressWarnings("unchecked")
	public List<StateDO> retriveAll() {
		return session.getNamedQuery(StateDO.FIND_ALL).list();
	}

	@SuppressWarnings("unchecked")
	public List<StateDO> retrievebyID(long id) {
		return session.getNamedQuery(StateDO.FIND_BY_STATE_ID).setParameter(CommonConstats.STATE_ID, id).list();
	}

	@SuppressWarnings("finally")
	public boolean update(StateDO stateDO) {
		boolean status=true;
		
		try {
			session.update(stateDO);
			session.beginTransaction().commit();
			
		} catch (Exception e) {
			e.printStackTrace();
			status=false;
		}finally{
		return status;
	}
	}

	@SuppressWarnings("finally")
	public boolean delete(StateDO stateDO) {
boolean status=true;
		
		try {
			session.delete(stateDO);
			session.beginTransaction().commit();
			
		} catch (Exception e) {
			e.printStackTrace();
			status=false;
		}finally{
		return status;
	}
	}
}
