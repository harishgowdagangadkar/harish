package com.countrystate.DAO;

import java.util.List;

import org.hibernate.Session;

import com.countrystate.domainobject.CountryDO;
import com.countrystate.util.CommonConstatns;
import com.countrystate.util.Singleton;

public class CountryDAO {

	Session session = Singleton.getSf().openSession();

	@SuppressWarnings({ "finally", "unchecked" })
	public boolean persist(CountryDO countryDO) {
		boolean status = true;
		try {
			/*session.save(countryDO);
			session.beginTransaction().commit();*/
			List<CountryDO> countryList =  session.getNamedQuery(CountryDO.FIND_COUNTRY_NAME)
					.setParameter(CommonConstatns.COUNTRY_NAME, countryDO.getCountryName())
					.list();
			if(countryList != null && countryList.size() > 0){
			session.persist(countryDO);
			session.beginTransaction().commit();
			}else{
				status = false;
			}
		} catch (Exception e) {
			status = false;
			System.out.println(status + "in dao");
			e.printStackTrace();
		} finally {
			return status;
		}
	}

	@SuppressWarnings("unchecked")
	public List<CountryDO> retrieveById(long id) {

		return session.getNamedQuery(CountryDO.FIND_BY_ID).setParameter(CommonConstatns.ID, id).list();
	}

	@SuppressWarnings("unchecked")
	public List<CountryDO> retriveAll() {

		return session.getNamedQuery(CountryDO.FIND_BY_ALL).list();

	}

	@SuppressWarnings("finally")
	public boolean delete(CountryDO countryDO) {
		boolean status = true;
		try {
			session.delete(countryDO);
			session.beginTransaction().commit();
		} catch (Exception e) {
			status = false;
			e.printStackTrace();
		} finally {
			return status;
		}

	}

	public boolean update(CountryDO countryDO) {
		boolean status = true;
		try {
			@SuppressWarnings("unchecked")
			List<CountryDO> list = session.getNamedQuery(CountryDO.FIND_COUNTRY_NAME)
					.setParameter(CommonConstatns.COUNTRY_NAME, countryDO.getCountryName()).list();
			if (list != null && list.size() > 0) {
				status = false;
			} else {
				session.update(countryDO);
				session.beginTransaction().commit();
			}
		} catch (Exception e) {
			e.printStackTrace();
			status = false;
		}

		return status;
	}

	public CountryDO retrievebyUniqueID(long id) {
		return (CountryDO) session.getNamedQuery(CountryDO.FIND_BY_ID).setParameter(CommonConstatns.ID, id)
				.uniqueResult();
	}

}
