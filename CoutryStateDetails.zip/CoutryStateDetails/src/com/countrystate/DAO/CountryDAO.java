package com.countrystate.DAO;

import java.util.List;

import org.hibernate.Session;

import com.countrystate.domainobject.CountryDO;
import com.countrystate.util.CommonConstats;
import com.countrystate.util.Singleton;

public class CountryDAO {

	
	Session session=Singleton.getSf().openSession();
	@SuppressWarnings("finally")
	public boolean persist(CountryDO countryDO) {
		boolean status=true;
		try {
			session.save(countryDO);
			session.beginTransaction().commit();
			
		} catch (Exception e) {
			status=false;
			System.out.println(status+"in dao");
			e.printStackTrace();
		}finally{
			return status;
		}
	}
	@SuppressWarnings("unchecked")
	public List<CountryDO> retrieveById(long id) {

		return session.getNamedQuery(CountryDO.FIND_BY_ID).setParameter(CommonConstats.ID, id).list();
	}
	@SuppressWarnings("unchecked")
	public List<CountryDO> retriveAll() {
		
		return session.getNamedQuery(CountryDO.FIND_BY_ALL).list();
		
	}
	@SuppressWarnings("finally")
	public boolean delete(CountryDO countryDO) {
		boolean status=true;
		try {
			session.delete(countryDO);
			session.beginTransaction().commit();
		} catch (Exception e) {
			status=false;
			e.printStackTrace();
		}finally{
			return status;
		}
		

}
	public boolean update(CountryDO countryDO) {
		boolean status=true;
		try {
			session.update(countryDO);
			session.beginTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			status=false;
		}
		
		return status;
	}
}
