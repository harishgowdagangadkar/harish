package com.countrystate.rs;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.countrystate.domainobject.CountryDO;
import com.countrystate.service.CountryService;
import com.countrystate.util.CommonConstats;
import com.countrystate.util.CommonWebUtil;
import com.countrystate.util.CountryUtil;


@Controller
@RequestMapping(value="/country")
public class CountryRS {
	

	@Autowired
	private CountryUtil countryUtil;
	@Autowired
	private CountryService countryService;
	
	
	
	@RequestMapping(value="/persist" ,method = RequestMethod.GET)
	public @ResponseBody String add(Model model,HttpServletRequest request) throws JSONException, IOException{
		try {
			
			CountryDO countryDO=new CountryDO();
			org.json.simple.JSONObject inputJSON = CommonWebUtil.getInputParams(request.getParameter(CommonConstats.DATA).toString());
			if (inputJSON != null){
		 		if(inputJSON.get(CommonConstats.NAME) != null && !inputJSON.get(CommonConstats.NAME).toString().isEmpty()){
		 			countryDO.setCountryName(inputJSON.get(CommonConstats.NAME).toString());
		 		}
		 		countryDO.setCreatedon(new Date());
			}
			if(!countryService.persist(countryDO)){
				return new JSONObject().put("your data", CommonConstats.ERROR_MSG).toString();
			}else{
			return new JSONObject().put("your data", CommonConstats.SUCCESS_MSG).toString();
						}
		} catch (Exception e) {
			e.printStackTrace();
			return new JSONObject().put("your data", CommonConstats.ERROR_MSG).toString();
		}
	}
	
	
	@RequestMapping(value = "/retriveAll", method = RequestMethod.GET)
	public @ResponseBody String retieve( Model model) {
		List<CountryDO> detailsDO=countryService.retriveAll();
		String detalis=null;
		detalis=countryUtil.getdetaliList(detailsDO).toString();
		return detalis ;
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
    public @ResponseBody String  deleteById(Model model,HttpServletRequest request) throws NumberFormatException, JSONException{
		org.json.simple.JSONObject inputJSON = CommonWebUtil.getInputParams(request.getParameter(CommonConstats.DATA).toString());
	CountryDO countryDO;
	JSONObject jSONObject=new JSONObject();
		if(inputJSON != null){
			List<CountryDO> 
			 list=countryService.retrievebyID(Long.parseLong(inputJSON.get(CommonConstats.ID).toString()));
			countryDO=list.get(0);
			if(countryService.delete(countryDO)){
				jSONObject.put(CommonConstats.SUCCESS, "data deleted");
				jSONObject.put(CommonConstats.ERROR, "");
			}
		} else{
			jSONObject.put(CommonConstats.ERROR, "data not deleted");
			jSONObject.put(CommonConstats.ERROR, "");
		}
		return jSONObject.toString();
     }
	
	
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public @ResponseBody String update(Model model,HttpServletRequest request) throws JSONException{
		JSONObject resultJSON = new JSONObject();
		JSONObject responsebject=new JSONObject();
		org.json.simple.JSONObject inputJSON = CommonWebUtil.getInputParams(request.getParameter(CommonConstats.DATA).toString());
		//System.out.println(inputJSON.get(CommonConstats.ID).toString());
		if(inputJSON != null){
		List<CountryDO> list=countryService.retrievebyID(Long.parseLong(inputJSON.get(CommonConstats.ID).toString()));
		for (CountryDO countryDO : list) {
			if(countryDO.getCountryId()==Long.parseLong(inputJSON.get(CommonConstats.ID).toString())){
				countryDO.setCountryName(inputJSON.get(CommonConstats.NAME).toString());
				if(countryService.update(countryDO)){
					resultJSON.put(CommonConstats.SUCCESS, "data updated");
					resultJSON.put(CommonConstats.ERROR, "");
				}else{
					resultJSON.put(CommonConstats.ERROR, "data not updated");
					resultJSON.put(CommonConstats.ERROR, "");
				}
			}
		}
		}else{
			resultJSON.put(CommonConstats.ERROR, "data not updated");
			resultJSON.put(CommonConstats.ERROR, "");
		}
		return responsebject.put(CommonConstats.RESULT, resultJSON).toString();
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
