package com.countrystate.rs;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.countrystate.domainobject.CountryDO;
import com.countrystate.service.CountryService;
import com.countrystate.util.CommonConstatns;
import com.countrystate.util.CommonWebUtil;
import com.countrystate.util.CountryUtil;

@Controller
@RequestMapping(value = "/country")
public class CountryRS {

	// autowiring the required objects
	@Autowired
	private CountryUtil countryUtil;
	@Autowired
	private CountryService countryService;

	@RequestMapping(value = "/persist", method = RequestMethod.GET)
	public @ResponseBody String add(Model model, HttpServletRequest request) throws JSONException, IOException {
		try {

			CountryDO countryDO = new CountryDO();
			org.json.simple.JSONObject inputJSON = CommonWebUtil
					.getInputParams(request.getParameter(CommonConstatns.DATA).toString());     
			System.out.println(inputJSON.get(CommonConstatns.NAME).toString());
			if (inputJSON != null) {
				if (inputJSON.get(CommonConstatns.NAME) != null
						&& !inputJSON.get(CommonConstatns.NAME).toString().isEmpty()) {
					countryDO.setCountryName(inputJSON.get(CommonConstatns.NAME).toString());
				}
				countryDO.setCreatedon(new Date());
			}
			if (!countryService.persist(countryDO)) {
				return CommonWebUtil.buildErrorResponse("country already added").toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return CommonWebUtil.buildErrorResponse("data cannot be added").toString();
		}
		return CommonWebUtil.buildSuccessResponse().toString();
	}// end of persist

	@RequestMapping(value = "/retrieveAll", method = RequestMethod.GET)
	public @ResponseBody String retieve(Model model) throws JSONException, ParseException {
		try {
			List<CountryDO> list = countryService.retriveAll();
			if (list != null && list.size() > 0) {
				String detalis = null;
				detalis = countryUtil.getdetaliList(list).toString();
				return detalis;
			} 
		} catch (Exception e) {
			return CommonWebUtil.buildErrorResponse("data cannot be retrieved").toString();
		} 
		return CommonWebUtil.buildErrorResponse("data cannot be retrieved").toString();
	}// end of retreiveAll

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public @ResponseBody String deleteById(Model model, HttpServletRequest request)
			throws NumberFormatException, JSONException {
		try {
			org.json.simple.JSONObject inputJSON = CommonWebUtil
					.getInputParams(request.getParameter(CommonConstatns.DATA).toString());
			if (inputJSON != null) {
				CountryDO countryDO = countryService
						.retrievebyUniqueID(Long.parseLong(inputJSON.get(CommonConstatns.ID).toString()));
				if (countryDO != null) {
					if (countryService.delete(countryDO)) {
						return CommonWebUtil.buildSuccessResponse().toString();
					}
				} else {
					return CommonWebUtil.buildErrorResponse("no data available").toString();
				}
			}
		} catch (Exception e) {
			return CommonWebUtil.buildErrorResponse("data not deleted").toString();
		}
		return CommonWebUtil.buildErrorResponse("data not deleted").toString();
	}// end of delete

	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public @ResponseBody String update(Model model, HttpServletRequest request) throws JSONException {
		try {
			org.json.simple.JSONObject inputJSON = CommonWebUtil
					.getInputParams(request.getParameter(CommonConstatns.DATA).toString());
			System.out.println(inputJSON);
			if (inputJSON != null) {
				CountryDO countryDO = countryService
						.retrievebyUniqueID(Long.parseLong(inputJSON.get(CommonConstatns.ID).toString()));
				if (countryDO != null) {
					countryDO.setCountryName(inputJSON.get(CommonConstatns.NAME).toString());
					if (countryService.update(countryDO)) {
						return CommonWebUtil.buildSuccessResponse().toString();
					}
				} else {
					return CommonWebUtil.buildErrorResponse("no data available").toString();
				}
			}
		} catch (Exception e) {
			return CommonWebUtil.buildErrorResponse("data already present").toString();
		}
		return CommonWebUtil.buildErrorResponse("country Already Added").toString();

	}// end of update

}// end of class
