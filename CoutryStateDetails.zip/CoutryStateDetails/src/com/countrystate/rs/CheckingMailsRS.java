package com.countrystate.rs;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.countrystate.util.CommonConstatns;
import com.countrystate.util.CommonEmailConstants;
import com.countrystate.util.EmailUtil;
import com.countrystate.util.CommonUtil;
import com.countrystate.util.CommonWebUtil;

@Controller
@RequestMapping(value = "/email")
public class CheckingMailsRS {

	@RequestMapping(value = "/read", method = RequestMethod.GET)
	public @ResponseBody String emailRead(Model model, HttpServletRequest request) throws MessagingException {

		try {
			org.json.simple.JSONObject inputJSON = CommonWebUtil
					.getInputParams(request.getParameter(CommonConstatns.DATA).toString());
			String host = "pop.gmail.com";// change accordingly
			String mailStoreType = "pop3";
			String username = "harishgowda261995@gmail.com";// change
															// accordingly
			String password = inputJSON.get(CommonEmailConstants.PASSWORD).toString();// change
																						// accordingly
			Message[] message = EmailUtil.read(host, mailStoreType, username, password);
			CommonUtil.getEmailInbox(message);
			return CommonUtil.getEmailInbox(message).toString();
		} catch (Exception e) {
			e.printStackTrace();
			CommonWebUtil.buildErrorResponse("data cannot be retrieved").toString();
		}
		return CommonWebUtil.buildErrorResponse("wrong credentials").toString();

	}

	@RequestMapping(value = "/send", method = RequestMethod.GET)
	public @ResponseBody String sendMail(Model model, HttpServletRequest request) throws MessagingException {
		try {
			org.json.simple.JSONObject inputJSON = CommonWebUtil
					.getInputParams(request.getParameter(CommonConstatns.DATA).toString());
			String username = inputJSON.get(CommonEmailConstants.USERNAME).toString();
			String password = inputJSON.get(CommonEmailConstants.PASSWORD).toString();
			String to = inputJSON.get(CommonEmailConstants.TO).toString();
			if (EmailUtil.sendMail(username, password, to)) {
				return CommonWebUtil.buildEmailSuccessResponse().toString();
			} else {
				return CommonWebUtil.buildErrorResponse("message not sent").toString();
			}
		} catch (Exception e) {
			return CommonWebUtil.buildErrorResponse("authentication error").toString();
		}
	}

}