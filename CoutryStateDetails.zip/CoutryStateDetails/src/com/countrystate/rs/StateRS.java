package com.countrystate.rs;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.countrystate.domainobject.StateDO;
import com.countrystate.service.CountryService;
import com.countrystate.service.StateService;
import com.countrystate.util.CommonConstatns;
import com.countrystate.util.CommonWebUtil;
import com.countrystate.util.StateUtil;

@Controller
@RequestMapping(value = "/state")
public class StateRS {

	// autowiring the required objects...................
	@Autowired
	private StateUtil stateUtil;

	@Autowired
	private CountryService countryService;

	@Autowired
	private StateService stateService;

	@RequestMapping(value = "/persist", method = RequestMethod.GET)
	public @ResponseBody String add(Model model, HttpServletRequest request) throws JSONException {
		try {
			StateDO stateDO = new StateDO();
			org.json.simple.JSONObject inputJSON = CommonWebUtil
					.getInputParams(request.getParameter(CommonConstatns.DATA).toString());
			if (inputJSON != null) {
				if (inputJSON.get(CommonConstatns.NAME) != null
						&& !inputJSON.get(CommonConstatns.NAME).toString().isEmpty()) {
					stateDO.setStateName(inputJSON.get(CommonConstatns.NAME).toString());
					stateDO.setCountry(countryService.retrieveById(Long.parseLong(CommonConstatns.COUNTRY_ID)).get(0));
				}
			}
			if (!stateService.persist(stateDO)) {
				return CommonWebUtil.buildErrorResponse("no data available").toString();
			}
		} catch (Exception e) {
			e.printStackTrace();

			return CommonWebUtil.buildErrorResponse("unable to add the data").toString();
		}
		return CommonWebUtil.buildSuccessResponse().toString();
	}// end of persist................

	@RequestMapping(value = "/retrieveAll", method = RequestMethod.GET)
	public @ResponseBody String retrievAll(Model model, HttpServletRequest request) {
		JSONObject JSONObject = null;
		try {
			List<StateDO> list = stateService.retriveAll();
			if (list != null && list.size() > 0) {
				System.out.println(list);
				JSONObject = stateUtil.getStateList(list);
				return JSONObject.toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return CommonWebUtil.buildErrorResponse("no data available").toString();
		}
		return CommonWebUtil.buildErrorResponse("data unable to retrieve").toString();
	}// end of retrieveAll................

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public @ResponseBody String deleteById(Model model, HttpServletRequest request)
			throws NumberFormatException, JSONException {
		try {
			org.json.simple.JSONObject inputJSON = CommonWebUtil
					.getInputParams(request.getParameter(CommonConstatns.DATA).toString());
			if (inputJSON != null) {
				StateDO stateDO = stateService
						.retrievebyUniqueID(Long.parseLong(inputJSON.get(CommonConstatns.ID).toString()));
				if (stateDO != null) {
					if (stateService.delete(stateDO)) {
						return CommonWebUtil.buildSuccessResponse().toString();
					}
				} else {
					return CommonWebUtil.buildErrorResponse("no data available").toString();
				}
			}
		} catch (Exception e) {
			return CommonWebUtil.buildErrorResponse("data not deleted").toString();
		}
		return CommonWebUtil.buildErrorResponse("data not deleted").toString();
	}// end of delete........................

	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public @ResponseBody String update(Model model, HttpServletRequest request) throws JSONException {
		try {
			org.json.simple.JSONObject inputJSON = CommonWebUtil
					.getInputParams(request.getParameter(CommonConstatns.DATA).toString());
			// System.out.println(inputJSON.get(CommonConstats.ID).toString());
			System.out.println(inputJSON);
			if (inputJSON != null) {
				StateDO stateDO = stateService
						.retrievebyUniqueID(Long.parseLong(inputJSON.get(CommonConstatns.ID).toString()));
				if (stateDO != null) {
					stateDO.setStateName(inputJSON.get(CommonConstatns.NAME).toString());
					if (stateService.update(stateDO)) {
						return CommonWebUtil.buildSuccessResponse().toString();
					}
				} else {
					return CommonWebUtil.buildErrorResponse("no data available").toString();
				}
			}
		} catch (Exception e) {
			return CommonWebUtil.buildErrorResponse("state already present").toString();
		}
		return CommonWebUtil.buildErrorResponse("state name already present").toString();

	}// end of update.................................

	@RequestMapping(value = "/retrievebycountry", method = RequestMethod.GET)
	public @ResponseBody String findBycountrName(Model model, HttpServletRequest request) throws JSONException {
		JSONObject response = new JSONObject();
		try {
			org.json.simple.JSONObject inputJSON = CommonWebUtil
					.getInputParams(request.getParameter(CommonConstatns.DATA).toString());
			System.out.println(inputJSON.get(CommonConstatns.NAME).toString());
			List<StateDO> detailsDO = stateService.find(inputJSON.get(CommonConstatns.NAME).toString());
			if (detailsDO != null && detailsDO.size() > 0) {
				response = stateUtil.getStateList(detailsDO);
				return response.toString();
			} else {
				return CommonWebUtil.buildErrorResponse("no data available").toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return CommonWebUtil.buildErrorResponse("data couldn't retrieve").toString();
		}

	}

	@RequestMapping(value = "/a", method = RequestMethod.GET)
	public @ResponseBody String seeAll(Model model, HttpServletRequest request) throws JSONException {
		org.json.simple.JSONObject inputJSON = CommonWebUtil
				.getInputParams(request.getParameter(CommonConstatns.DATA).toString());
		stateService.findall(inputJSON.get(CommonConstatns.NAME).toString());
		return "see console";
	}

}// end of class.........................
