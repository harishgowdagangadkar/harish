package com.countrystate.rs;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.countrystate.domainobject.CountryDO;
import com.countrystate.domainobject.StateDO;
import com.countrystate.service.CountryService;
import com.countrystate.service.StateService;
import com.countrystate.util.CommonConstats;
import com.countrystate.util.CommonWebUtil;
import com.countrystate.util.StateUtil;
@Controller
@RequestMapping(value="/state")
public class StateRS {

	@Autowired
	private StateUtil stateUtil;
	@Autowired
	private CountryService countryService;
	@Autowired
	private StateService stateService;
	
	@RequestMapping(value = "/persist", method = RequestMethod.GET)
	public @ResponseBody String add(Model model, HttpServletRequest request) throws JSONException {
		StateDO stateDO=new StateDO();
		try {
			stateDO.setStateName(request.getParameter(CommonConstats.NAME));
			List<CountryDO> countryList = countryService.retrieveById(Long.parseLong(CommonConstats.COUNTRY_ID));
			if(countryList != null && countryList.size()>0){
				stateDO.setCountry(countryList.get(0));
			}
			if(!stateService.persist(stateDO)){
				return new JSONObject().put("your data", CommonConstats.ERROR_MSG).toString();
			}else{
			return new JSONObject().put("your data", CommonConstats.SUCCESS_MSG).toString();
		}
		} catch (Exception e) {
			e.printStackTrace();

			return new JSONObject().put("your data", CommonConstats.SUCCESS_MSG).toString();
		}
		
	}
	@RequestMapping(value = "/retriveAll", method = RequestMethod.GET)
	public @ResponseBody String retrievAll(Model model,HttpServletRequest request){
		
		List<StateDO> stateDO=stateService.retriveAll();
		String detalis=null;
		detalis=stateUtil.getdetaliList(stateDO).toString();
		return detalis;
		
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
    public @ResponseBody String  deleteById(Model model,HttpServletRequest request) throws NumberFormatException, JSONException{
		org.json.simple.JSONObject inputJSON = CommonWebUtil.getInputParams(request.getParameter(CommonConstats.DATA).toString());
		StateDO StateDO;
		JSONObject jSONObject=new JSONObject();
			if(inputJSON != null){
				List<StateDO> 
				 list=stateService.retrievebyID(Long.parseLong(inputJSON.get(CommonConstats.ID).toString()));
				StateDO=list.get(0);
				if(stateService.delete(StateDO)){
					jSONObject.put(CommonConstats.SUCCESS, "data deleted");
					jSONObject.put(CommonConstats.ERROR, "");
				}
			} else{
				jSONObject.put(CommonConstats.ERROR, "data not deleted");
				jSONObject.put(CommonConstats.ERROR, "");
			}
			return jSONObject.toString();
     }
        
        @RequestMapping(value = "/update", method = RequestMethod.GET)
    	public @ResponseBody String update(Model model,HttpServletRequest request) throws JSONException{
        	JSONObject resultJSON = new JSONObject();
    		JSONObject responsebject=new JSONObject();
    		org.json.simple.JSONObject inputJSON = CommonWebUtil.getInputParams(request.getParameter(CommonConstats.DATA).toString());
    		//System.out.println(inputJSON.get(CommonConstats.ID).toString());
    		if(inputJSON != null){
    		List<StateDO> list=stateService.retrievebyID(Long.parseLong(inputJSON.get(CommonConstats.ID).toString()));
    		for (StateDO stateDO : list) {
    			if(stateDO.getStateId()==Long.parseLong(inputJSON.get(CommonConstats.ID).toString())){
    				stateDO.setStateName(inputJSON.get(CommonConstats.NAME).toString());
    				if(stateService.update(stateDO)){
    					resultJSON.put(CommonConstats.SUCCESS, "data updated");
    					resultJSON.put(CommonConstats.ERROR, "");
    				}else{
    					resultJSON.put(CommonConstats.ERROR, "data not updated");
    					resultJSON.put(CommonConstats.ERROR, "");
    				}
    			}
    		}
    		}else{
    			resultJSON.put(CommonConstats.ERROR, "data not updated");
    			resultJSON.put(CommonConstats.ERROR, "");
    		}
    		return responsebject.put(CommonConstats.RESULT, resultJSON).toString();
    		}
}
