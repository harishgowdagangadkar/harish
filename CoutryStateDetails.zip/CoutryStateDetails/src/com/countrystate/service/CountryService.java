package com.countrystate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.countrystate.DAO.CountryDAO;
import com.countrystate.domainobject.CountryDO;

public class CountryService {

	@Autowired
	private CountryDAO countryDAO;
	
	
	public boolean persist(CountryDO countryDO) {
		return countryDAO.persist(countryDO);
	}
	public List<CountryDO> retrieveById(long id) {
		return countryDAO.retrieveById(id);
		 
	}
	public List<CountryDO> retriveAll() {
		return countryDAO.retriveAll();
	}
	public List<CountryDO> retrievebyID(long id) {
		return countryDAO.retrieveById(id);
	}
	public boolean delete(CountryDO countryDO) {
		
		return countryDAO.delete(countryDO);
	}
	public boolean update(CountryDO countryDO) {
		return countryDAO.update(countryDO);
	}
	public CountryDO retrievebyUniqueID(long id) {
		return countryDAO.retrievebyUniqueID(id);
	}
	

}
