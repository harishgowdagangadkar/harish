package com.countrystate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.countrystate.DAO.StateDAO;
import com.countrystate.domainobject.StateDO;

public class StateService {

	@Autowired
	private StateDAO stateDAO;

	public boolean persist(StateDO stateDO) {
		return stateDAO.persist(stateDO);

	}

	public List<StateDO> retriveAll() {
		return stateDAO.retriveAll();
	}

	public List<StateDO> retrievebyID(long parseLong) {
		return stateDAO.retrievebyID(parseLong);
	}

	public boolean update(StateDO stateDO) {
		return stateDAO.update(stateDO);
	}

	public boolean delete(StateDO stateDO) {
		return stateDAO.delete(stateDO);
	}

	public List<StateDO> find(String string) {

		return stateDAO.find(string);
	}

	public void findall(String string) {
		stateDAO.findall(string);
	}

	public StateDO retrievebyUniqueID(long parseLong) {
		return stateDAO.retrievebyUniqueID(parseLong);
	}

}
